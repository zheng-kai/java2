package component.mainboard;

import component.Mainboard;

public class Gigabyte extends Mainboard {
    public Gigabyte(String name, float price, float speed) {
        super(name, price, speed);
    }
}
