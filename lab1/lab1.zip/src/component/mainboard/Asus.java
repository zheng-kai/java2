package component.mainboard;

import component.Mainboard;

public class Asus extends Mainboard {
    public Asus(String name, float price, float speed) {
        super(name, price, speed);
    }
}
