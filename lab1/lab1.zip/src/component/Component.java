package component;

public interface Component {
    void work();
}
