package component.cpu;

import component.CPU;

public class Intel extends CPU {
    public Intel(String name, float price, int coreNum) {
        super(name, price, coreNum);
    }
}
