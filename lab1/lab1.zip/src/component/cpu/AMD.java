package component.cpu;

import component.CPU;

public class AMD extends CPU {
    public AMD(String name, float price, int coreNum) {
        super(name, price, coreNum);
    }
}
