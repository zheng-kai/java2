package component.disk;

import component.Disk;

public class WestDigitals extends Disk {
    public WestDigitals(String name, float price, int volume) {
        super(name, price, volume);
    }
}
