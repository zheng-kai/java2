package component.disk;

import component.Disk;

public class Seagate extends Disk {
    public Seagate(String name, float price, int volume) {
        super(name, price, volume);
    }
}
