package component.memory;

import component.Memory;

public class Samsung extends Memory {
    public Samsung(String name, float price, int volume) {
        super(name, price, volume);
    }
}
