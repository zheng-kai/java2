package component.memory;

import component.Memory;

public class Kingston extends Memory {
    public Kingston(String name, float price, int volume) {
        super(name, price, volume);
    }
}
